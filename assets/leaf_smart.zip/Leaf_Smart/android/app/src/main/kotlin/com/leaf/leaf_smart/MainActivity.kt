package com.leaf.leaf_smart

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
